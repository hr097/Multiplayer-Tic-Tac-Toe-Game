﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TictaetoeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TictaetoeForm))
        Me.LabelNumOfPlayers = New System.Windows.Forms.Label()
        Me.ComboBoxNumOfPlayers = New System.Windows.Forms.ComboBox()
        Me.LinkLabelSeeRules = New System.Windows.Forms.LinkLabel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LabelNumOfPlayers
        '
        Me.LabelNumOfPlayers.AutoSize = True
        Me.LabelNumOfPlayers.Font = New System.Drawing.Font("SF Compact Display", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LabelNumOfPlayers.Location = New System.Drawing.Point(35, 36)
        Me.LabelNumOfPlayers.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.LabelNumOfPlayers.Name = "LabelNumOfPlayers"
        Me.LabelNumOfPlayers.Size = New System.Drawing.Size(348, 34)
        Me.LabelNumOfPlayers.TabIndex = 0
        Me.LabelNumOfPlayers.Text = "Select number of players :"
        '
        'ComboBoxNumOfPlayers
        '
        Me.ComboBoxNumOfPlayers.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboBoxNumOfPlayers.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBoxNumOfPlayers.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ComboBoxNumOfPlayers.DisplayMember = "5"
        Me.ComboBoxNumOfPlayers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxNumOfPlayers.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ComboBoxNumOfPlayers.Font = New System.Drawing.Font("SF Compact Display", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.ComboBoxNumOfPlayers.FormattingEnabled = True
        Me.ComboBoxNumOfPlayers.Items.AddRange(New Object() {"" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "2", "" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "3", "" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "4", "" & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & Global.Microsoft.VisualBasic.ChrW(9) & "5"})
        Me.ComboBoxNumOfPlayers.Location = New System.Drawing.Point(35, 101)
        Me.ComboBoxNumOfPlayers.MaxDropDownItems = 6
        Me.ComboBoxNumOfPlayers.MaxLength = 256
        Me.ComboBoxNumOfPlayers.Name = "ComboBoxNumOfPlayers"
        Me.ComboBoxNumOfPlayers.Size = New System.Drawing.Size(328, 41)
        Me.ComboBoxNumOfPlayers.Sorted = True
        Me.ComboBoxNumOfPlayers.TabIndex = 2
        '
        'LinkLabelSeeRules
        '
        Me.LinkLabelSeeRules.ActiveLinkColor = System.Drawing.Color.Purple
        Me.LinkLabelSeeRules.AutoSize = True
        Me.LinkLabelSeeRules.Font = New System.Drawing.Font("SF Compact Display", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LinkLabelSeeRules.LinkColor = System.Drawing.Color.MidnightBlue
        Me.LinkLabelSeeRules.Location = New System.Drawing.Point(152, 251)
        Me.LinkLabelSeeRules.Name = "LinkLabelSeeRules"
        Me.LinkLabelSeeRules.Size = New System.Drawing.Size(90, 21)
        Me.LinkLabelSeeRules.TabIndex = 3
        Me.LinkLabelSeeRules.TabStop = True
        Me.LinkLabelSeeRules.Text = "See Rules"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button1.FlatAppearance.BorderSize = 10
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("SF Compact Display", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(97, 177)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(205, 51)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "START GAME"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TictaetoeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(19.0!, 39.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(412, 303)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.LinkLabelSeeRules)
        Me.Controls.Add(Me.ComboBoxNumOfPlayers)
        Me.Controls.Add(Me.LabelNumOfPlayers)
        Me.Font = New System.Drawing.Font("SF Compact Display", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(430, 350)
        Me.MinimumSize = New System.Drawing.Size(430, 350)
        Me.Name = "TictaetoeForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tic Tac Toe  -  Multiplayer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelNumOfPlayers As Label
    Friend WithEvents ComboBoxNumOfPlayers As ComboBox
    Friend WithEvents LinkLabelSeeRules As LinkLabel
    Friend WithEvents Button1 As Button
End Class
